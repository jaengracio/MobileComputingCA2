package com.college.ca2college.model.api;

import com.college.ca2college.model.Course;
import com.college.ca2college.model.Enrolment;
import com.college.ca2college.model.Student;
import com.college.ca2college.model.User;

import java.util.List;

public abstract class AbstractAPIListener implements APIListener {
    @Override
    public void onLogin(User user) { }

    @Override
    public void onEnrolmentsLoaded(List<Enrolment> enrolments) { }

    @Override
    public void onCoursesLoaded(List<Course> courses) { }

    @Override
    public void onStudentsLoaded(List<Student> students) { }

    @Override
    public void onEnrolmentStored(Enrolment storedEnrolment) { }

    @Override
    public void onEnrolmentUpdated(Enrolment updatedEnrolment) { }

    @Override
    public void onEnrolmentDeleted(Enrolment deletedEnrolment) { }
}
