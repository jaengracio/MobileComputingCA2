package com.college.ca2college;

import android.app.Application;
import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.Toast;

import com.college.ca2college.model.Course;
import com.college.ca2college.model.Enrolment;
import com.college.ca2college.model.Model;
import com.college.ca2college.model.Student;
import com.college.ca2college.model.api.AbstractAPIListener;

import java.util.List;
import java.util.zip.Inflater;

/* This fragment displays the form viewing, editing the details of an enrolment
   and for making a new enrolment. */
public class EnrolmentFragment extends Fragment {

    public static final String ARG_ENROLMENT_ID = "enrolment_id";

    public static EnrolmentFragment newInstance(int enrolmentId) {
        EnrolmentFragment fragment = new EnrolmentFragment();
        Bundle args = new Bundle();
        args.putInt(ARG_ENROLMENT_ID, enrolmentId);
        fragment.setArguments(args);
        return fragment;
    }

    private EditText mDateText;
    private EditText mTimeText;
    private Spinner mCoursesSpinner;
    private Spinner mStudentsSpinner;
    private RadioButton mRegisteredButton;
    private RadioButton mAttendingButton;
    private RadioButton mDeferredButton;
    private RadioButton mWithdrawnButton;

    private Model mModel;
    private int mEnrolmentId;
    private Enrolment mEnrolment;
    private boolean mEditMode;

    public EnrolmentFragment() {
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if(getArguments() != null){
            Bundle arguments  = getArguments();
            mEnrolmentId = arguments.getInt(ARG_ENROLMENT_ID);
            /* When the activity is created and there is no enrolment id,
               a new enrolment object will be made with default values.
               If there is an id, it will look for it in the model. */
            mModel = Model.getInstance(this.getActivity().getApplication());
            if(mEnrolmentId == 0){
                mEnrolment = new Enrolment(0,"","",0,0,Enrolment.REGISTERED);
            }
            else {
                mEnrolment = mModel.findEnrolmentById(mEnrolmentId);
            }
            setHasOptionsMenu(true);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_enrolment, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState){
       mDateText = view.findViewById(R.id.dateText);
       mTimeText = view.findViewById(R.id.timeText);
       mCoursesSpinner = view.findViewById(R.id.coursesSpinner);
       mStudentsSpinner = view.findViewById(R.id.studentsSpinner);
       mRegisteredButton = view.findViewById(R.id.radio_registered);
       mAttendingButton = view.findViewById(R.id.radio_attending);
       mDeferredButton = view.findViewById(R.id.radio_deferred);
       mWithdrawnButton = view.findViewById(R.id.radio_withdrawn);

       populateForm();

       if(mEnrolmentId == 0){
           setEditMode(true);
       }
       else {
           setEditMode(false);
       }
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.action_bar_menu, menu);
        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public void onPrepareOptionsMenu(Menu menu) {
        MenuItem edit = menu.findItem(R.id.action_edit);
        /* When viewing an enrolment, the icon in the menu bar is
           a pencil but changes to a floppy disk while editing. */
        if (mEditMode){
            edit.setIcon(R.drawable.baseline_save_white_48dp);
            edit.setTitle("Save");
        }
        else {
            edit.setIcon(R.drawable.baseline_edit_white_48dp);
            edit.setTitle("Edit");
        }
        super.onPrepareOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        switch (item.getItemId()){
            case R.id.action_edit: {
              /* If there is no enrolment id, the object is stored.
                 If there is, the object is updated.
                 A message is shown if the user clicks the edit button. */
                if(mEditMode){
                    Enrolment enrolment = getFormData();
                    if(mEnrolmentId == 0){
                        storeEnrolment(enrolment);
                    }
                    else {
                        updateEnrolment(enrolment);
                    }
                }
                else {
                    Toast.makeText(getActivity(), "Edit selected", Toast.LENGTH_LONG).show();
                }
                setEditMode(!mEditMode);

                getActivity().invalidateOptionsMenu();

                return false;
            }
            case R.id.action_delete: {
                mModel.deleteEnrolment(mEnrolment, new AbstractAPIListener() {
                    @Override
                    public void onEnrolmentDeleted(Enrolment deletedEnrolment) {
                        if (deletedEnrolment == null){
                            Toast.makeText(getActivity(), "Enrolment not deleted", Toast.LENGTH_LONG).show();
                        }
                        else {
                            mModel.deleteEnrolment(deletedEnrolment);

                            Toast.makeText(getActivity(), "Enrolment deleted", Toast.LENGTH_LONG).show();

                            EnrolmentFragment.this.getActivity().finish();
                        }
                    }
                });
                return false;
            }
        }
        return super.onOptionsItemSelected(item);
    }

    private void storeEnrolment (Enrolment enrolment){
        mModel.storeEnrolment(enrolment, new AbstractAPIListener() {
            @Override
            public void onEnrolmentStored(Enrolment storedEnrolment){
                if (storedEnrolment == null){
                   Toast.makeText(getActivity(), "Enrolment not stored", Toast.LENGTH_LONG).show();
                }
                else {
                    setEnrolment(storedEnrolment);

                    mModel.storeEnrolment(mEnrolment);

                    Toast.makeText(getActivity(), "Enrolment stored", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    private void updateEnrolment (Enrolment enrolment){
        mModel.updateEnrolment(enrolment, new AbstractAPIListener() {
            @Override
            public void onEnrolmentStored(Enrolment updatedEnrolment){
                if (updatedEnrolment == null){
                    Toast.makeText(getActivity(), "Enrolment not updated", Toast.LENGTH_LONG).show();
                }
                else {
                    setEnrolment(updatedEnrolment);
                    Toast.makeText(getActivity(), "Enrolment updated", Toast.LENGTH_LONG).show();
                }
            }
        });
    }
/* Fills the form objects with data. */
    private void populateForm() {
        mDateText.setText(mEnrolment.getDate());
        mTimeText.setText(mEnrolment.getTime());

        populateCourseSpinner();
        populateStudentSpinner();

        mRegisteredButton.setChecked(mEnrolment.getStatus().equals(Enrolment.REGISTERED));
        mAttendingButton.setChecked(mEnrolment.getStatus().equals(Enrolment.ATTENDING));
        mDeferredButton.setChecked(mEnrolment.getStatus().equals(Enrolment.DEFERRED));
        mWithdrawnButton.setChecked(mEnrolment.getStatus().equals(Enrolment.WITHDRAWN));
    }
/* Fills the dropdown menu for the course with course objects. */
    private void populateCourseSpinner() {
        List<Course> courses = mModel.getCourses();
        final ArrayAdapter<Course> coursesAdapter = new ArrayAdapter<>(
                this.getActivity(), android.R.layout.simple_spinner_item, courses);
        coursesAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mCoursesSpinner.setAdapter(coursesAdapter);

        if(courses.size() == 0){
            mModel.loadCourses(new AbstractAPIListener() {
                @Override
                public void onCoursesLoaded(List<Course> courseList){
                    if (courseList != null && !courseList.isEmpty()){
                        mModel.addCourses(courseList);
                        coursesAdapter.notifyDataSetChanged();
                        mCoursesSpinner.setSelection(coursesAdapter.getPosition(mEnrolment.getCourse()));
                    }
                }
            });
        }
        else {
            mCoursesSpinner.setSelection(coursesAdapter.getPosition(mEnrolment.getCourse()));
        }
    }

    private void populateStudentSpinner() {
        List<Student> students = mModel.getStudents();
        final ArrayAdapter<Student> studentsAdapter = new ArrayAdapter<>(
                this.getActivity(), android.R.layout.simple_spinner_item, students);
        studentsAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mStudentsSpinner.setAdapter(studentsAdapter);

        if(students.size() == 0){
            mModel.loadStudents(new AbstractAPIListener() {
                @Override
                public void onStudentsLoaded(List<Student> studentList){
                    if (studentList != null && !studentList.isEmpty()){
                        mModel.addStudents(studentList);
                        studentsAdapter.notifyDataSetChanged();
                        mStudentsSpinner.setSelection(studentsAdapter.getPosition(mEnrolment.getStudent()));
                    }
                }
            });
        }
        else {
            mStudentsSpinner.setSelection(studentsAdapter.getPosition(mEnrolment.getStudent()));
        }
    }

    private void setEditMode(boolean editMode) {
        mEditMode = editMode;
        mDateText.setEnabled(editMode);
        mTimeText.setEnabled(editMode);
        mCoursesSpinner.setEnabled(editMode);
        mStudentsSpinner.setEnabled(editMode);
        mRegisteredButton.setEnabled(editMode);
        mAttendingButton.setEnabled(editMode);
        mDeferredButton.setEnabled(editMode);
        mWithdrawnButton.setEnabled(editMode);
    }
/* Retrieves and stores data for enrolment objects. */
    private Enrolment getFormData() {
        int id =  mEnrolment.getId();
        String date = mDateText.getText().toString();
        String time = mTimeText.getText().toString();
        Course course = (Course) mCoursesSpinner.getSelectedItem();
        int courseId = course.getId();
        Student student = (Student) mStudentsSpinner.getSelectedItem();
        int studentId = student.getId();
        String status = getFormStatus();

        Enrolment enrolment = new Enrolment(id, date, time, courseId, studentId, status);
        enrolment.setCourse(course);
        enrolment.setStudent(student);

        return enrolment;
    }
/* Sets value for the radio buttons. */
    private String getFormStatus(){
        String status = null;
        if(mRegisteredButton.isChecked()){
            status = Enrolment.REGISTERED;
        }
        else if(mAttendingButton.isChecked()){
            status = Enrolment.ATTENDING;
        }
        else if(mDeferredButton.isChecked()){
            status = Enrolment.DEFERRED;
        }
        else if(mWithdrawnButton.isChecked()){
            status = Enrolment.WITHDRAWN;
        }
        return status;
    }
/* Sets values for the enrolment objects. */
    private void setEnrolment(Enrolment enrolment) {
        mEnrolment.setId(enrolment.getId());
        mEnrolment.setDate(enrolment.getDate());
        mEnrolment.setTime(enrolment.getTime());
        mEnrolment.setCourseId(enrolment.getCourseId());
        mEnrolment.setStudentId(enrolment.getStudentId());
        mEnrolment.setStatus(enrolment.getStatus());
        Course course = mModel.findCourseById(enrolment.getCourseId());
        mEnrolment.setCourse(course);
        Student student = mModel.findStudentById(enrolment.getStudentId());
        mEnrolment.setStudent(student);

    }
}
