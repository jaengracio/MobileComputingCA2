package com.college.ca2college;

import android.app.Application;
import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment; //had an error previously due to diff versions of Fragment
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.college.ca2college.model.Enrolment;
import com.college.ca2college.model.Model;
import com.college.ca2college.model.api.AbstractAPIListener;
import java.util.List;

/* EnrolmentsFragment is a part of the main interface.
   This fragment displays a list of all the enrolments. */
public class EnrolmentsFragment extends Fragment {

    public static EnrolmentsFragment newInstance() {
        EnrolmentsFragment fragment = new EnrolmentsFragment();
        return fragment;
    }

    private OnFragmentInteractionListener mListener;
    private EnrolmentsAdapter adapter;

    public EnrolmentsFragment() {
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    /* onCreateView creates a view object which references the enrolments fragment.
       Inside the fragment is a recyclerView containing a list of items
       i.e. enrolments. */
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_enrolments, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState){
        if(view instanceof RecyclerView){
            Context context = view.getContext();
            RecyclerView recyclerView = (RecyclerView) view;
            recyclerView.setLayoutManager(new LinearLayoutManager(context));
            /* DividerItemDecoration adds a divider to the list of items. */
            DividerItemDecoration decoration = new DividerItemDecoration(context, DividerItemDecoration.VERTICAL);
            recyclerView.addItemDecoration(decoration);

            Application application = this.getActivity().getApplication();
            Model model = Model.getInstance(application);
            final List<Enrolment> enrolments = model.getEnrolments();
            /* This adapter allows the recyclerView to acces data objects or enrolment objects.  */
            adapter = new EnrolmentsAdapter(this, enrolments);
            recyclerView.setAdapter(adapter);
            model.loadEnrolments(new AbstractAPIListener() {
                @Override
                public void onEnrolmentsLoaded(List<Enrolment> loadedEnrolments){
                    enrolments.clear();
                    enrolments.addAll(loadedEnrolments);
                    adapter.notifyDataSetChanged();
                }
            });
        }
    }
    /* Listens to the users interaction with the fragment. */
    public void onItemSelected(Enrolment enrolment) {
        if (mListener != null) {
            mListener.onItemSelected(enrolment);
        }
    }

    @Override
    public void onResume() {
        super.onResume();
            /* The recyclerView is refreshed after deleting an item */
            adapter.notifyDataSetChanged();
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        }
        else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    public interface OnFragmentInteractionListener {
        void onItemSelected(Enrolment enrolment);
    }
}
