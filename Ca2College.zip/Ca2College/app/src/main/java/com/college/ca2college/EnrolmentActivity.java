package com.college.ca2college;

import android.content.Intent;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.college.ca2college.model.Enrolment;

public class EnrolmentActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enrolment);

        Intent intent = getIntent();
        int enrolmentId = intent.getIntExtra(EnrolmentFragment.ARG_ENROLMENT_ID, 0);

        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        EnrolmentFragment fragment = EnrolmentFragment.newInstance(enrolmentId);
        ft.add(R.id.enrolment_container, fragment);
        ft.commit();
    }
}
