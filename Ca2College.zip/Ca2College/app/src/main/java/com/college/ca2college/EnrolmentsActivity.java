package com.college.ca2college;

import android.content.Intent;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;
import com.college.ca2college.model.Enrolment;

public class EnrolmentsActivity extends AppCompatActivity implements EnrolmentsFragment.OnFragmentInteractionListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enrolments);
/* A FrameLayout object is made which references the container in the
   activity_enrolments layout. A fragment object is also made which
   is put into the FrameLayout object. */
        FrameLayout container = findViewById(R.id.enrolments_container);
        if(container != null) {
            Fragment fragment = EnrolmentsFragment.newInstance();
            FragmentManager fm = getSupportFragmentManager();
            FragmentTransaction ft = fm.beginTransaction();
            ft.add(R.id.enrolments_container, fragment);
            ft.commit();
        }
/* This creates an add button at the bottom right of the activity.
   When the button is clicked, a new activity is started.*/
        FloatingActionButton button = findViewById(R.id.action_add);
        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(EnrolmentsActivity.this, EnrolmentActivity.class);
                startActivity(intent);
            }
        });
    }
/* When an item from the list of enrolment objects is clicked, a new acticity starts
   and the id of the enrolment object is retrieved. */
    @Override
    public void onItemSelected(Enrolment enrolment) {
        Intent intent = new Intent(this, EnrolmentActivity.class);
        intent.putExtra(EnrolmentFragment.ARG_ENROLMENT_ID, enrolment.getId());
        startActivity(intent);
    }
}
