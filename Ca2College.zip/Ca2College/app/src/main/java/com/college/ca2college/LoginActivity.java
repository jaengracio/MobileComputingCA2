package com.college.ca2college;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.college.ca2college.model.Model;
import com.college.ca2college.model.User;
import com.college.ca2college.model.api.AbstractAPIListener;

public class LoginActivity extends AppCompatActivity {

/* Whenever an activity starts, the activity is created and sets
   the view to a layout. */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

/* These references the ids for the components in the layout file for the login activity */
        final EditText emailField = findViewById(R.id.emailText);
        final EditText passwordField = findViewById(R.id.passwordText);
        Button loginBtn = findViewById(R.id.loginBtn);
/* This creates an instance of the sub class View.OnClickListener. This enables us to decide
   what we want to happen when the login button is clicked. */
        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                /* This takes the text object from the form and coverts it into a string */
                String email = emailField.getText().toString();
                String password = passwordField.getText().toString();

                final Model model = Model.getInstance(LoginActivity.this.getApplication());
                model.login(email, password, new AbstractAPIListener() {
                    /* This checks if the user exists. If it does the
                       EnrolmentsActivity is started and if not an error
                       message will be shown. */
                    public void onLogin(User user) {
                        if (user != null){
                            model.setUser(user);
                            Intent intent = new Intent(LoginActivity.this, EnrolmentsActivity.class);
                            startActivity(intent);
                        }
                        else{
                            Toast.makeText(LoginActivity.this, "Invalid login", Toast.LENGTH_LONG).show();
                        }
                    }
                });
            }
        });
    }
}
